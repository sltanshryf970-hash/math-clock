package com.sultan.mathclock

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("math_clock", Context.MODE_PRIVATE) }
    private val spinners = mutableListOf<Spinner>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(7, 9, 10)) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(text("ساعة الرياضيات", 26f, Color.WHITE, true))
        root.addView(text("اختار معادلة مستقلة لكل رقم من أرقام الساعة. كل المعادلات في القائمة محسوبة لتساوي الرقم المعروض.", 14f, 0xFFB6C1C2.toInt()))
        root.addView(text("معاينة الأداة", 18f, 0xFFE5ECEB.toInt(), true).apply {
            setPadding(0, dp(18), 0, dp(6))
        })
        root.addView(text("بعد حفظ الاختيارات، أضف أداة «ساعة الرياضيات» من قائمة الأدوات في الشاشة الرئيسية.", 13f, 0xFF9AA8AA.toInt()))

        for (hour in 1..12) {
            val label = text("موضع الساعة $hour", 16f, Color.WHITE, true).apply {
                setPadding(0, dp(14), 0, dp(5))
            }
            root.addView(label)
            val formulas = FormulaBank.bank[hour].orEmpty()
            val options = formulas.map { "${it.category} | ${it.expression}" }
            val spinner = Spinner(this).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, options)
                setSelection(prefs.getInt("choice_$hour", 0).coerceIn(0, options.lastIndex))
                backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF718184.toInt())
            }
            spinners.add(spinner)
            root.addView(spinner, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48)
            ))
        }

        val save = Button(this).apply {
            text = "حفظ المعادلات وتحديث الساعة"
            setOnClickListener {
                val editor = prefs.edit()
                for (i in 1..12) editor.putInt("choice_$i", spinners[i - 1].selectedItemPosition)
                editor.apply()
                MathClockWidget.updateAll(this@MainActivity)
                text = "تم الحفظ وتحديث الساعة"
            }
        }
        val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54))
        params.topMargin = dp(24)
        root.addView(save, params)

        root.addView(text("طريقة إضافة الأداة", 18f, Color.WHITE, true).apply {
            setPadding(0, dp(22), 0, dp(8))
        })
        root.addView(text("اضغط مطولًا على مكان فارغ في الشاشة الرئيسية ← الأدوات (Widgets) ← ساعة الرياضيات ← اسحب الأداة إلى الشاشة. يمكنك تغيير حجمها من خلال الضغط المطول عليها.", 14f, 0xFFB6C1C2.toInt()))
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            gravity = Gravity.START
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
